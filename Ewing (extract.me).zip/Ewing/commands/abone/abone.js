const Discord = require('discord.js');
const db = require('croxydb');

exports.run = function(client, message) {
const embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setTitle('> Abone Yardım Komutları')
.setTimestamp()
.addField('> e?abonerol ', 'Abone Rolü Ayarlarsınız')
.addField('> e?aboneyrol ', 'Yetkili Rolü Ayarlarsınız')
.addField('> e?abone', 'Rol verirsiniz')
.addField('> e?abonestats', 'Etiketlediğiniz kişinin veya kendinizin istatistiklerine bakarsınız.')
.addField('> e?asayısıfırla', 'Stats Sayısı Sıfırlarsınız.')
.setImage('')
.setFooter('Ewing', client.user.avatarURL())
.setTimestamp()
.setThumbnail(client.user.avatarURL())
message.channel.send(embed)
};

exports.conf = {
  enabled: true,
  guildOnly: false, 
  aliases: ["abone-yardım"], 
  permLevel: 0 
};

exports.help = {
  name: 'abone-yardım',
  description: 'Tüm komutları gösterir.',
  usage: 'yardım'
};