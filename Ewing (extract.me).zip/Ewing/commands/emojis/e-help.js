const Discord = require('discord.js');
const qdb = require('quick.db');

exports.run = async(client, message, args) => {
  let prefix = await require('quick.db').fetch(`prefix_${message.guild.id}`) || `e?`
  let onlycode = args.slice(0).join(' ');


const embed = new Discord.MessageEmbed()
.setTitle('Emoji Yardım Menüsü')
.addField(`**> Hızlı Yükle **`, `Hızlı bir şekilde emoji yüklemek için \`${prefix}hızlı-yükle <emoji/dosya/link> \``)
.addField(`**> Emoji Adlandır**`, `Belirtilen emojinin ismini değiştirir \`${prefix}adlandır <emoji> \``)
.addField(`**> Emoji Al**`, `Belirtilen mesajdaki emojiyi bulur \`${prefix}emoji-al mesaj-id> \``)
.addField(`**> Emoji Ara**`, `botun olduğu sunucularda istenen emojiyi arar \`${prefix}ara <emoji>\``)
.setImage("")
message.channel.send(embed)
};
exports.conf = {
  aliases: ['emoji', 'emoji-yardım'],
  permLevel: 0
};
exports.help = {
  name: "emojiler"
}