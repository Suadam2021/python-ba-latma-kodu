const db = require("quick.db")
const dc = require("discord.js")

exports.run = async (client, message, args) => {
  
	let prefix = await require('quick.db').fetch(`prefix_${message.guild.id}`) || `e?`

const embed = new dc.MessageEmbed()
.setTitle('Yedek Yardım Menüsü')
.addField(`**> Yedek almak **`, `Sunucunu yedeklemek için bu komutu kullanabilirsin; \`${prefix}yedek-al\`\nDikkat, yedek idni kimseyle paylaşma! `)
.addField(`**> Yedek Bilgi **`, `yedeğinin bilgisini almanı sağlar \`${prefix}yedek-bilgi <yedek-id> \` `)
.addField(`**> Yedek Liste**`, `Bottaki yedekleri listeler \`${prefix}yedek-liste \` `)
.addField(`**> Yedek Sil **`, `Bota kayıtlı olan bir yedeğini siler \`${prefix}yedek-sil <yedek-id> \` `)
.addField(`**> Yedek Yükle**`, `Önceden aldığın bir yedeği bota yükler \`${prefix}yedek-yükle <yedek-id> \` `)
message.channel.send(embed)
}


exports.conf = {
  aliases: ['yedek-yardım', 'yardım-yedek', 'yedek'],
  permLevel: 0
};
exports.help = {
  name: "yedek-yardım"
}