const db = require("croxydb");
const Discord = require('discord.js');
 const ayarlar = require('../../ayarlar.json');
exports.run = async (client, message, args) => { 
 
let eklenti = new Discord.MessageEmbed()  
.setAuthor(` Guard Komutları`, client.user.avatarURL())
.setThumbnail(message.author.displayAvatarURL({dynamic : true}))
.setColor('#f6ff00')
.addField(` > __Ban Koruması__`,` \`e?ban-koruma\` Ban Korumasını Aktif Eder.`,true)
.addField(` > __Spam Koruması__`,` \`e?spam\` Spam Korumasını Aktif Eder.`,true)
.addField(` > __Self Koruma__`,` \`e?self-koruma\` Self Botları Susturur.`,true)
.addField(` > __Bot Koruması__`,` \`e?anti-raid\` Bot Korumasını Aktif Eder.`,true)
.addField(` > __Reklam Koruması__`,` \`e?reklamengel\` Reklam Korumasını Aktif Eder.`,true)
.addField(` > __Reklam-Log Koruması__`,` \`e?reklamlog\` Reklam Yapınca Mesajı Siler Kanal'a Atar.`,true)
.addField(` > __Küfür Koruması__`,` \`e?küfür-engelle\` Küfür Korumasını Aktif Eder.`,true)
 message.channel.send(eklenti) 
  };
  exports.conf = {
    enabled: true,  
    guildOnly: false, 
    aliases: ["guard-yardım"], 
    permLevel: 0
  };
  exports.help = {
    name: 'guard-yardım'
  }; 
  