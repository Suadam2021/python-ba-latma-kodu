const Discord = require('discord.js');
const qdb = require('quick.db');

exports.run = async(client, message, args) => {

  let prefix = await require('quick.db').fetch(`prefix_${message.guild.id}`) || `.`
  let onlycode = args.slice(0).join(' ');
const embed = new Discord.MessageEmbed()
.setTitle('Kayıt Yardım Menüsü')
.addField(`**> Kayıtsız rol**`, `\nErkek Kayıt yapılınca kişiye verilecek rol, \`${prefix}erkek-rol <@etiket>\`\nKadın Kayıt yapılınca kişiye verilecek rol, \`${prefix}kadın-rol <@etiket>\``)
.addField(`**> Verecek Yetkili **`, `Kayıt yapacak yetkili rolü \`${prefix}kayıt-yetkili @etiket / <id> \``)
.addField(`**> Kayıt Alınan Rol **`, `Kayıt yapılınca kişiden alınacak rol \`${prefix}kayıtsız-rol @unregistered/kayıtsız \``)
.addField(`**> Kayıt etme komutları **`, `Erkek kayıt komutu \`${prefix}erkek <@etiket> \`\nKadın kayıt komutu \`${prefix}kadın <@etiket> \``)
.addField(`**> NOT!**`, `birisi gelince karşılamak için, gelen-giden bölümüne göz atabilirsin.`)
.setFooter('e?kayıt-kanal: kayıt kanalı.')
.setImage("")
message.channel.send(embed)
};
exports.conf = {
  aliases: ['kayıt', 'kayıt-sistemi', 'kayıt-yardım'],
  permLevel: 0
};
exports.help = {
  name: "kayıt"
}