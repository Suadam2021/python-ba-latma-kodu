const Discord = require('discord.js');
const qdb = require('quick.db');
const ayarlar = require('../../ayarlar.json');
exports.run = async(client, message, args) => {
  var a = qdb.fetch(`prefix_${message.guild.id}`) //ewing
  if(a){ 
    var p = a
  }
  if(!a){
    var p = ayarlar.prefix
  }
  const embed = new Discord.MessageEmbed()
  .setColor("00447e")
  .setAuthor(`${client.user.username} Komutları`, client.user.displayAvatarURL({dynamic: true})
  )
  .addField(`**> ${p}welcomer**`, "Giriş çıkış komutlarını gösterir.", true)
  .addField(`**> ${p}kayıt-yardım**`, "Kayıt komutlarını gösterir.", true)
  .addField(`**> ${p}emoji-yardım**`, "Emoji komutlarını gösterir.", true)
  .addField(`**> ${p}yedek-yardım**`, "Sunucu yedekleme komutlarını gösterir", true)
  .addField(`**> ${p}otocevap**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}abone-yardım**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}guard-yardım**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}logo-yardım**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}moderasyon-yardım**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}moderasyon2**`, "Bota otocevap ekleyebilirsiniz.", true)
  .addField(`**> ${p}moderasyon3**`, "Bota otocevap ekleyebilirsiniz.", true)


  
  .setFooter(`${message.author.username} istedi!`, message.author.displayAvatarURL({dynamic: true}))
  .setImage("")
  return message.channel.send(embed)
};
exports.conf = {
  aliases: ["h", "yardım", "y"],
  permLevel: 0
}
exports.help = {
  name: "help"
}