const Discord = require('discord.js');
const qdb = require('quick.db');

exports.run = async(client, message, args) => {
	msg = message

  let prefix = await require('quick.db').fetch(`prefix_${msg.guild.id}`) || `.`
  let onlycode = args.slice(0).join(' ');
const embed = new Discord.MessageEmbed()
.setTitle('Giriş-Çıkış Menüsü')
.addField(`**> Otorol**`, `Sunucunuzda otorol ayarlamak için \`${prefix}otorol @rol\` kullanabilirsiniz`)
.addField(`**> Embed Renkler**`, `Çıkış embed rengini değiştirmek için;  \`${prefix}çıkış-renk #renkkodu\`\ngiriş embed rengini değiştirmek için \`${prefix}giriş-renk #renkkodu\` `)
.addField(`**> Giriş/Çıkış Kanalları **`, `Çıkış kanalını ayarlamak için \`.çıkış-kanal #kanal\`\nGiriş kanalını ayarlamak için \`${prefix}giriş-kanal #kanal\``)
.addField(`**> Giriş/Çıkış Mesajları**`, `Giriş mesajını ayarlamak için \`${prefix}giriş-mesaj <mesaj>\`\nÇıkış mesajını ayarlamak için \`${prefix}çıkış-mesaj <mesaj>\` `)
.addField(`**> Ayarları Sıfırla **`, `Giriş/Çıkış ayarlarını sıfırlamak istiyorsan \`${prefix}gelip-giden sıfırla\` `)
.setImage("")

message.channel.send(embed)
};
exports.conf = {
  aliases: ['welcomer', 'giriş-çıkış'],
  permLevel: 0
};
exports.help = {
  name: "gelen-giden"
}