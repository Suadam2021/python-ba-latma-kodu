const db = require("croxydb");
const Discord = require('discord.js');
const ayarlar = require('../../ayarlar.json');
exports.run = async (client, message, args) => { 
 
let eklenti = new Discord.MessageEmbed()  
.setAuthor(`Moderasyon Komutları`, client.user.avatarURL())
.setThumbnail(message.author.displayAvatarURL({dynamic : true}))
.setColor('#f6ff00')
.addField(`>  __Ban Log__`,` \`e?ban-log\` Ban Log Kanalı Ayarlarsınız.`,true)
.addField(`>  __Ban Yetkili Rol__`,` \`e?ban-yetkili-rol\` Sadece Kimler Banlayabilir?`,true)
.addField(`>  __Ban__`,` \`e?ban <@üye> <sebep>\` Kişiyi Banlarsınız.`,true)
.addField(`>  __Ban Kaldır__`,` \`e?unban <KişiID> <Sebep> \` Belirtiğiniz Kişinin Banını Açar.`,true)
.addField(`>  __Ban Affı__`,` \`e?banaffı \` Bütün Yasaklıların Banını Açar.`,true)
.addField(`>  __Kick Log__`,` \`e?kick-log\`  Kick Log Kanalı Ayarlarsınız.`,true)
.addField(`>  __Kick Yetkili Rol__`,` \`e?kick-yetkili-rol\` Sadece Kimler Kick Atabilir?`,true)
.addField(`>  __Kick__`,` \`e?kick <@üye> <sebep> \` Kişiyi Sunucudan Kicklersiniz.`,true)
.addField(`>  __Moderasyon3__`,` \`e?moderasyon3 \` | Moderasyon Menüsünün Devamı.`,true)
 message.channel.send(eklenti) 
  };
  exports.conf = {
    enabled: true,  
    guildOnly: false, 
    aliases: ["moderasyon2","ayarlar2"], 
    permLevel: 0
  };
  exports.help = {
    name: 'moderasyon2'
  }; 
  