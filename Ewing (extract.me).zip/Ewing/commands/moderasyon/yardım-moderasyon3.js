const db = require("croxydb");
const Discord = require('discord.js');
exports.run = async (client, message, args) => { 
let eklenti = new Discord.MessageEmbed()  
.setAuthor(`Moderasyon Komutları`, client.user.avatarURL())
.setThumbnail(message.author.displayAvatarURL({dynamic : true}))
.setColor('#f6ff00')
.addField(`  __Mute Log__`,` \`e?mute-log #kanal \` Mute Log Kanalı Ayarlarsınız.`,true)
.addField(`  __Mute Log Kapat__`,` \`e?mute-log-kapat \` Mute Log Kanalını Sıfırlar.`,true)
.addField(`  __Mute Yetkili Rol__`,` \`e?mute-yetkili-rol <@rol> \` Sadece Kimler Mute Atabilir?`,true)
.addField(`  __Mute Yetkili Rol Sil__`,` \`e?muteyetki-sil \` Otomatik Selamlamayı Açar/Kapatır.`,true)
.addField(`  __Mute__`,` \`e?mute <@üye> <1s> <1m> <1h> <1d> \` Otomatik Selamlamayı Açar/Kapatır.`,true)
.addField(`  __Sunucu Paneli__`,` \`e?panel-kur\` Sunucu Kanallarını Açar`,true)
.addField(`  __Paneli Kaldır__`,` \`e?panel-sil\` Panel Kanallarını Siler`,true)
message.channel.send(eklenti) 
  };
  exports.conf = {
    enabled: true,  
    guildOnly: false, 
    aliases: ["moderasyon3","ayarlar3"], 
    permLevel: 0
  };
  exports.help = {
    name: 'moderasyon3'
  }; 
  