const db = require("croxydb");
const Discord = require('discord.js');
const ayarlar = require('../../ayarlar.json');
exports.run = async (client, message, args) => { 
 
let eklenti = new Discord.MessageEmbed()  
.setAuthor(`Moderasyon Komutları`, client.user.avatarURL())
.setThumbnail(message.author.displayAvatarURL({dynamic : true}))
.setColor('#f6ff00')
.addField(`>  __Ejderha__`,` \`e?ejderha <yazi>\` Ejderha Logo Atar`,true)
.addField(`>  __Vip__`, `\`e?vip <yazi>\` Vip Logo Atar`,true)
.addField(`>  __Alev__`,`\`e?alev <yazi>\` Alev Logo Atar`,true)
.addField(`>  __Gemi__`,`\`e?gemi <yazi>\` Gemi Logo Atar`,true)
.addField(`>  __Duckets__`,` \`e?duckets <yazi>\` Duckets Logo Atar`,true)
.addField(`>  __Buz__`,` \`e?buz <yazi>\` Buz Logo Atar`,true)
.addField(`>  __Arrow__`,` \`e?arrow <yazi>\` Arrow Logo Atar`,true)
.addField(`>  __Neon__`,` \`e?neon <yazi>\` Neon Logo Atar`,true)
.addField(`>  __Fx__`,` \`e?fx <yazi>\` Fx Logo Atar`,true)
.addField(`>  __Mekanik__`,` \`e?mekanik <yazi>\` Mekanik Logo Atar`,true)
.addField(`>  __Metal__`,` \`e?metal <yazi>\` Metal Logo Atar`,true)
.addField(`>  __Punk__`,` \`e?punk <yazi>\` Punk Logo Atar`,true)
.addField(`>  __Sci-fi__`,` \`e?sci-fi <yazi>\`Sci-fi logo atar.`,true)
.addField(`>  __Siyah__`,` \`e?siyah <yazi>\`Siyah logo atar.`,true)
.addField(`>  __Taş__`,` \`e?taş <yazi>\`Taş logo atar.`,true)
 message.channel.send(eklenti) 
  };
  exports.conf = {
    enabled: true,  
    guildOnly: false, 
    aliases: ["logo-yardım"], 
    permLevel: 0
  };
  exports.help = {
    name: 'logo-yardım'
  }; 
  