const Discord = require("discord.js");
const qdb = require('quick.db')
const ayarlar = require('../ayarlar.json');
module.exports = message => {
var client = message.client
var a = qdb.fetch(`prefix_${message.guild.id}`)
if(a){ //ewing
  var p = a
}
if(!a){ //ewing
  var p = ayarlar.prefix
}
const embedimsi = new Discord.MessageEmbed()
.setColor("00447e")
.setAuthor(`${client.user.username}`, client.user.displayAvatarURL({dynamic: true}))
.setTitle(`Merhaba!${client.user.username}`) //ewing
.setDescription(`
Bu sunucudaki prefix'im: \`${p}\`
Yardım : \`${p}yardım\`
Beni sunucuna eklemek için: \`${p}davet\`

**Geliştiricilerim:**
<@!774591026940739585>
root#4893`)
.setImage("")
.setFooter(`${message.author.username} istedi.`, message.author.displayAvatarURL({dynamic: true}))
if(message.content === `<@!${client.user.id}>`) return message.channel.send(embedimsi)
};

//ewing